require 'test_helper'

class FollowsHelperTest < ActionView::TestCase
end
